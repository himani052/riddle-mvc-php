create view course_participant as
select `test`.`score_user_course`.`scoreUser`       AS `scoreUser`,
       `test`.`score_user_course`.`user_emailUser`  AS `user_emailUser`,
       `test`.`score_user_course`.`course_idCourse` AS `course_idCourse`,
       `test`.`user`.`emailUser`                    AS `emailUser`,
       `test`.`user`.`pseudoUser`                   AS `pseudoUser`,
       `test`.`user`.`passwordUser`                 AS `passwordUser`,
       `test`.`user`.`birthdateUser`                AS `birthdateUser`,
       `test`.`user`.`photoUser`                    AS `photoUser`,
       `test`.`user`.`registrationDateUser`         AS `registrationDateUser`,
       `test`.`user`.`levelUser`                    AS `levelUser`,
       `test`.`user`.`totalScoreUser`               AS `totalScoreUser`,
       `test`.`user`.`admin`                        AS `admin`,
       `test`.`course`.`idCourse`                   AS `idCourse`,
       `test`.`course`.`titleCourse`                AS `titleCourse`,
       `test`.`course`.`descriptionCourse`          AS `descriptionCourse`,
       `test`.`course`.`distanceCourse`             AS `distanceCourse`,
       `test`.`course`.`imageCourse`                AS `imageCourse`,
       `test`.`course`.`creationDateCourse`         AS `creationDateCourse`,
       `test`.`course`.`creatorCourse`              AS `creatorCourse`
from ((`test`.`score_user_course` join `test`.`user` on ((`test`.`user`.`emailUser` =
                                                          `test`.`score_user_course`.`user_emailUser`)))
         join `test`.`course` on ((`test`.`course`.`idCourse` = `test`.`score_user_course`.`course_idCourse`)))
order by `test`.`course`.`idCourse`;

