create view courses_details as
select `test`.`course`.`idCourse`                    AS `idCourse`,
       `test`.`course`.`titleCourse`                 AS `titleCourse`,
       `test`.`course`.`descriptionCourse`           AS `descriptionCourse`,
       `test`.`course`.`distanceCourse`              AS `distanceCourse`,
       `test`.`course`.`imageCourse`                 AS `imageCourse`,
       `test`.`course`.`creationDateCourse`          AS `creationDateCourse`,
       `test`.`course`.`creatorCourse`               AS `creatorCourse`,
       `test`.`user`.`emailUser`                     AS `emailUser`,
       `test`.`user`.`pseudoUser`                    AS `pseudoUser`,
       `test`.`user`.`passwordUser`                  AS `passwordUser`,
       `test`.`user`.`birthdateUser`                 AS `birthdateUser`,
       `test`.`user`.`photoUser`                     AS `photoUser`,
       `test`.`user`.`registrationDateUser`          AS `registrationDateUser`,
       `test`.`user`.`levelUser`                     AS `levelUser`,
       `test`.`user`.`totalScoreUser`                AS `totalScoreUser`,
       `test`.`user`.`admin`                         AS `admin`,
       `test`.`location`.`idLocation`                AS `idLocation`,
       `test`.`location`.`titleLocation`             AS `titleLocation`,
       `test`.`location`.`descriptionLocation`       AS `descriptionLocation`,
       `test`.`location`.`imageLocation`             AS `imageLocation`,
       `test`.`location`.`addressLocation`           AS `addressLocation`,
       `test`.`location`.`department_codeDepartment` AS `department_codeDepartment`,
       `test`.`location`.`city_codeCity`             AS `city_codeCity`,
       `test`.`location`.`course_idCourse`           AS `course_idCourse`,
       `test`.`department`.`codeDepartment`          AS `codeDepartment`,
       `test`.`department`.`titleDepartment`         AS `titleDepartment`,
       `test`.`city`.`codeCity`                      AS `codeCity`,
       `test`.`city`.`titleCity`                     AS `titleCity`,
       `test`.`riddle`.`idRiddle`                    AS `idRiddle`,
       `test`.`riddle`.`titleRiddle`                 AS `titleRiddle`,
       `test`.`riddle`.`descriptionRiddle`           AS `descriptionRiddle`,
       `test`.`riddle`.`imageRiddle`                 AS `imageRiddle`,
       `test`.`riddle`.`solutionRiddle`              AS `solutionRiddle`,
       `test`.`riddle`.`location_idLocation`         AS `location_idLocation`,
       `test`.`clue`.`idClue`                        AS `idClue`,
       `test`.`clue`.`titleClue`                     AS `titleClue`,
       `test`.`clue`.`descriptionClue`               AS `descriptionClue`,
       `test`.`clue`.`imageClue`                     AS `imageClue`,
       `test`.`clue`.`riddle_idRiddle`               AS `riddle_idRiddle`
from ((((((`test`.`course` left join `test`.`user` on ((`test`.`course`.`creatorCourse` = `test`.`user`.`emailUser`))) left join `test`.`location` on ((`test`.`course`.`idCourse` = `test`.`location`.`course_idCourse`))) left join `test`.`department` on ((
        `test`.`location`.`department_codeDepartment` =
        `test`.`department`.`codeDepartment`))) left join `test`.`city` on ((`test`.`location`.`city_codeCity` = `test`.`city`.`codeCity`))) left join `test`.`riddle` on ((
        `test`.`location`.`idLocation` = `test`.`riddle`.`location_idLocation`)))
         left join `test`.`clue` on ((`test`.`clue`.`riddle_idRiddle` = `test`.`riddle`.`idRiddle`)))
order by `test`.`course`.`idCourse`;

