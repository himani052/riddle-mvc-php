create view course_by_creator as
select `test`.`course`.`idCourse`           AS `idCourse`,
       `test`.`course`.`titleCourse`        AS `titleCourse`,
       `test`.`course`.`descriptionCourse`  AS `descriptionCourse`,
       `test`.`course`.`distanceCourse`     AS `distanceCourse`,
       `test`.`course`.`imageCourse`        AS `imageCourse`,
       `test`.`course`.`creationDateCourse` AS `creationDateCourse`,
       `test`.`course`.`creatorCourse`      AS `creatorCourse`,
       `test`.`user`.`emailUser`            AS `emailUser`,
       `test`.`user`.`pseudoUser`           AS `pseudoUser`,
       `test`.`user`.`passwordUser`         AS `passwordUser`,
       `test`.`user`.`birthdateUser`        AS `birthdateUser`,
       `test`.`user`.`photoUser`            AS `photoUser`,
       `test`.`user`.`registrationDateUser` AS `registrationDateUser`,
       `test`.`user`.`levelUser`            AS `levelUser`,
       `test`.`user`.`totalScoreUser`       AS `totalScoreUser`,
       `test`.`user`.`admin`                AS `admin`
from (`test`.`course`
         join `test`.`user` on ((`test`.`course`.`creatorCourse` = `test`.`user`.`emailUser`)))
order by `test`.`course`.`idCourse`;

